module.exports=[13938,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_contact-records_page_actions_0h1eddyo1mksx.js.map