globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/wgUwXGfVcWMHbbTwzZhsN/_buildManifest.js",
    "static/wgUwXGfVcWMHbbTwzZhsN/_ssgManifest.js",
    "static/wgUwXGfVcWMHbbTwzZhsN/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0j1we3cwg31qe.js",
    "static/chunks/374e0i9_p69m6.js",
    "static/chunks/01t2i9pe5vz2-.js",
    "static/chunks/turbopack-2u1d16houkiyo.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/0j1we3cwg31qe.js",
        "static/chunks/374e0i9_p69m6.js",
        "static/chunks/01t2i9pe5vz2-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/0j1we3cwg31qe.js",
        "static/chunks/374e0i9_p69m6.js",
        "static/chunks/01t2i9pe5vz2-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/0j1we3cwg31qe.js",
        "static/chunks/374e0i9_p69m6.js",
        "static/chunks/01t2i9pe5vz2-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/contact-records/page": {
      "otherChunks": [
        "static/chunks/0j1we3cwg31qe.js",
        "static/chunks/374e0i9_p69m6.js",
        "static/chunks/01t2i9pe5vz2-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
