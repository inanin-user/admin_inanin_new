var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/contact-records/route.js")
R.c("server/chunks/[externals]__12s2uxrv8n30f._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/[root-of-the-server]__1fpy0wm2z9959._.js")
R.c("server/chunks/_next-internal_server_app_api_contact-records_route_actions_19tz09id1ndem.js")
R.m(96675)
module.exports=R.m(96675).exports
