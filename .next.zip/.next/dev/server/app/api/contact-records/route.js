var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/contact-records/route.js")
R.c("server/chunks/node_modules_next_02g_16cldlqu5._.js")
R.c("server/chunks/[root-of-the-server]__0rfdhbfijsrcu._.js")
R.c("server/chunks/_next-internal_server_app_api_contact-records_route_actions_19tz09id1ndem.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/contact-records/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/contact-records/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
