module.exports = [
"[project]/.next-internal/server/app/api/contact-records/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_contact-records_route_actions_19tz09id1ndem.js.map