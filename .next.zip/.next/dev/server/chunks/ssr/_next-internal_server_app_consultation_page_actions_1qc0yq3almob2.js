module.exports = [
"[project]/.next-internal/server/app/consultation/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_consultation_page_actions_1qc0yq3almob2.js.map