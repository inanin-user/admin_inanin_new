module.exports = [
"[project]/.next-internal/server/app/contact-records/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_contact-records_page_actions_0h1eddyo1mksx.js.map