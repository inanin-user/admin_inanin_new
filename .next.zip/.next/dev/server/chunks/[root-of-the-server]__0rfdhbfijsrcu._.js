module.exports = [
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/runtime-reacts.external.js [external] (next/dist/server/runtime-reacts.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/runtime-reacts.external.js", () => require("next/dist/server/runtime-reacts.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/node:fs/promises [external] (node:fs/promises, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("node:fs/promises", () => require("node:fs/promises"));

module.exports = mod;
}),
"[externals]/node:path [external] (node:path, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("node:path", () => require("node:path"));

module.exports = mod;
}),
"[externals]/node:stream [external] (node:stream, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("node:stream", () => require("node:stream"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[project]/app/api/contact-records/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET,
    "PUT",
    ()=>PUT
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
;
;
;
const CSV_PATH = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["resolve"])(process.cwd(), "..", "private_contact_data", "contact_submissions.csv");
// CSV parser supporting quoted values, escaped quotes and newlines.
function parseCSV(content) {
    const rows = [];
    let row = [];
    let field = "";
    let inQuotes = false;
    for(let i = 0; i < content.length; i++){
        const char = content[i];
        if (inQuotes) {
            if (char === '"') {
                if (content[i + 1] === '"') {
                    field += '"';
                    i++;
                } else {
                    inQuotes = false;
                }
            } else {
                field += char;
            }
        } else {
            if (char === '"') {
                inQuotes = true;
            } else if (char === ",") {
                row.push(field);
                field = "";
            } else if (char === "\n") {
                row.push(field);
                rows.push(row);
                row = [];
                field = "";
            } else if (char !== "\r") {
                field += char;
            }
        }
    }
    if (field.length > 0 || row.length > 0) {
        row.push(field);
        rows.push(row);
    }
    return rows.filter((r)=>r.some((value)=>value.trim() !== ""));
}
function normalizeHeader(value) {
    return value.replace(/^\uFEFF/, "").trim().toLowerCase().replace(/[\s_-]+/g, "");
}
async function GET() {
    try {
        const content = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["readFile"])(CSV_PATH, "utf8");
        const rows = parseCSV(content);
        if (rows.length === 0) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: true,
                records: []
            }, {
                headers: {
                    "Cache-Control": "no-store"
                }
            });
        }
        const firstRow = rows[0].map(normalizeHeader);
        const hasHeader = firstRow.includes("name") && firstRow.includes("phone");
        const headers = hasHeader ? firstRow : [
            "submissiondate",
            "name",
            "phone",
            "email",
            "system",
            "message"
        ];
        const dataRows = hasHeader ? rows.slice(1) : rows;
        function getValue(row, ...keys) {
            const index = headers.findIndex((header)=>keys.includes(header));
            return index >= 0 ? row[index] ?? "" : "";
        }
        const records = dataRows.map((row, index)=>{
            const timestamp = getValue(row, "submissiondate");
            return {
                id: `${timestamp || "record"}-${index}`,
                timestamp,
                name: getValue(row, "name"),
                phone: getValue(row, "phone"),
                email: getValue(row, "email"),
                system: getValue(row, "system"),
                message: getValue(row, "message"),
                comment: getValue(row, "comment")
            };
        });
        // Newest submissions first.
        records.reverse();
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            total: records.length,
            records
        }, {
            headers: {
                "Cache-Control": "no-store, no-cache, must-revalidate"
            }
        });
    } catch (error) {
        console.error("Contact CSV read error:", error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            message: "Unable to read contact submissions."
        }, {
            status: 500
        });
    }
}
// Keep your existing CSV_PATH, parseCSV() and normalizeHeader().
// Do not redeclare existing imports or constants.
function escapeCSV(value) {
    const safeValue = String(value ?? "");
    return `"${safeValue.replace(/"/g, '""')}"`;
}
function serializeCSV(rows) {
    return rows.map((row)=>row.map(escapeCSV).join(",")).join("\r\n") + "\r\n";
}
function normalizeValue(value, maxLength) {
    if (typeof value !== "string") return "";
    return value.trim().slice(0, maxLength);
}
async function PUT(request) {
    const lockPath = `${CSV_PATH}.lock`;
    const tempPath = `${CSV_PATH}.${Date.now()}.tmp`;
    let lockHandle = null;
    try {
        const body = await request.json();
        const id = normalizeValue(body.id, 300);
        const record = body.record;
        if (!id || !record || typeof record !== "object") {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                message: "Invalid request."
            }, {
                status: 400
            });
        }
        const updated = {
            name: normalizeValue(record.name, 150),
            phone: normalizeValue(record.phone, 50),
            email: normalizeValue(record.email, 254),
            system: normalizeValue(record.system, 150),
            message: normalizeValue(record.message, 5000),
            comment: normalizeValue(record.comment, 5000)
        };
        if (!updated.name || !updated.phone) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                message: "Name and phone are required."
            }, {
                status: 400
            });
        }
        // Acquire an exclusive lock to prevent simultaneous CSV writes.
        for(let attempt = 0; attempt < 30; attempt++){
            try {
                lockHandle = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["open"])(lockPath, "wx");
                break;
            } catch (error) {
                if (error.code !== "EEXIST") {
                    throw error;
                }
                await new Promise((resolve)=>setTimeout(resolve, 100));
            }
        }
        if (!lockHandle) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                message: "Another update is in progress. Please try again."
            }, {
                status: 409
            });
        }
        const content = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["readFile"])(CSV_PATH, "utf8");
        const rows = parseCSV(content);
        if (rows.length === 0) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                message: "CSV file is empty."
            }, {
                status: 404
            });
        }
        // Preserve the original CSV header names.
        const originalHeaders = rows[0];
        const headers = originalHeaders.map(normalizeHeader);
        const hasHeader = headers.includes("name") && headers.includes("phone");
        if (!hasHeader) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                message: "CSV header is invalid."
            }, {
                status: 500
            });
        }
        const timestampIndex = headers.findIndex((h)=>[
                "submissiondate"
            ].includes(h));
        const nameIndex = headers.findIndex((h)=>[
                "name"
            ].includes(h));
        const phoneIndex = headers.findIndex((h)=>[
                "phone"
            ].includes(h));
        const emailIndex = headers.indexOf("email");
        const systemIndex = headers.indexOf("system");
        const messageIndex = headers.findIndex((h)=>[
                "message"
            ].includes(h));
        // Add a comment column if it does not already exist.
        let commentIndex = headers.findIndex((h)=>[
                "comment"
            ].includes(h));
        if (commentIndex === -1) {
            originalHeaders.push("comment");
            rows.forEach((row, index)=>{
                if (index > 0) row.push("");
            });
            headers.push("comment");
            commentIndex = headers.length - 1;
        }
        // IDs are generated by GET as timestamp-rowIndex.
        // rowIndex is the data-row position before reverse().
        const separator = id.lastIndexOf("-");
        const rowIndex = Number(id.slice(separator + 1));
        const idTimestamp = id.slice(0, separator);
        if (separator < 0 || !Number.isInteger(rowIndex) || rowIndex < 0) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                message: "Invalid record ID."
            }, {
                status: 400
            });
        }
        const targetIndex = rowIndex + 1;
        const target = rows[targetIndex];
        if (!target) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                message: "Record not found."
            }, {
                status: 404
            });
        }
        const currentTimestamp = timestampIndex >= 0 ? target[timestampIndex] || "record" : "record";
        if (currentTimestamp !== idTimestamp) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                message: "Record identity changed. Please refresh the list."
            }, {
                status: 409
            });
        }
        function setColumn(index, value) {
            if (index >= 0) target[index] = value;
        }
        setColumn(nameIndex, updated.name);
        setColumn(phoneIndex, updated.phone);
        setColumn(emailIndex, updated.email);
        setColumn(systemIndex, updated.system);
        setColumn(messageIndex, updated.message);
        setColumn(commentIndex, updated.comment);
        // Write a temporary file, then atomically replace the CSV.
        const tempHandle = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["open"])(tempPath, "w", 0o600);
        try {
            await tempHandle.writeFile(serializeCSV(rows), "utf8");
        } finally{
            await tempHandle.close();
        }
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["rename"])(tempPath, CSV_PATH);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            message: "Record updated successfully."
        });
    } catch (error) {
        console.error("Contact CSV update error:", error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            message: "Unable to update contact record."
        }, {
            status: 500
        });
    } finally{
        if (lockHandle) {
            await lockHandle.close().catch(()=>{});
            await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["unlink"])(lockPath).catch(()=>{});
        }
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["unlink"])(tempPath).catch(()=>{});
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__0rfdhbfijsrcu._.js.map